<?php

require get_template_directory() . '/upsites/functions.php';
