<?php
/*
Template Name: Padrão
*/
get_header();
?>

<?php get_footer(); ?>




