<?php
/*
Template Name: Categoria
*/
get_header();

?>

<?php get_footer(); ?>




